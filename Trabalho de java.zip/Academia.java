import java.io.*;
import java.util.*;

class Aluno {
    String nome;
    int idade;
    
    public Aluno(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
}

class Instrutor {
    String nome;
    String especialidade;
    
    public Instrutor(String nome, String especialidade) {
        this.nome = nome;
        this.especialidade = especialidade;
    }
}

class Treino {
    String nome;
    List<Aluno> alunos;
    Instrutor instrutor;
    
    public Treino(String nome, Instrutor instrutor) {
        this.nome = nome;
        this.alunos = new ArrayList<>();
        this.instrutor = instrutor;
    }
    
    public void adicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }
    
    public void removerAluno(Aluno aluno) {
        alunos.remove(aluno);
    }
}

class FileManager {
    static final String FILENAME = "academia.txt";
    
    public static void salvar(String data) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILENAME, true))) {
            writer.println(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

public class Academia {
    static Scanner scanner = new Scanner(System.in);
    static List<Treino> treinos = new ArrayList<>();
    
    public static void main(String[] args) {
        while (true) {
            exibirMenu();
            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer
            
            switch (opcao) {
                case 1:
                    adicionarTreino();
                    break;
                case 2:
                    removerTreino();
                    break;
                case 3:
                    pesquisarTreino();
                    break;
                case 4:
                    listarTreinos();
                    break;
                case 5:
                    listarTreinosOrdenados();
                    break;
                default:
                    System.out.println("Opção inválida. Encerrando o programa.");
                    return;
            }
        }
    }
    
    static void exibirMenu() {
        System.out.println("\n===== MENU =====");
        System.out.println("1. Adicionar um Novo Treino");
        System.out.println("2. Remover um Treino Existente");
        System.out.println("3. Pesquisar um Treino");
        System.out.println("4. Listar Todos os Treinos");
        System.out.println("5. Listar os Treinos Ordenados");
        System.out.println("Digite o número correspondente à operação desejada:");
    }
    
    static void adicionarTreino() {
        System.out.println("\n===== ADICIONAR TREINO =====");
        System.out.println("Digite o nome do novo treino:");
        String nome = scanner.nextLine();
        
        System.out.println("Digite o nome do instrutor responsável:");
        String nomeInstrutor = scanner.nextLine();
        
        System.out.println("Digite a especialidade do instrutor:");
        String especialidade = scanner.nextLine();
        
        Instrutor instrutor = new Instrutor(nomeInstrutor, especialidade);
        Treino treino = new Treino(nome, instrutor);
        treinos.add(treino);
        
        FileManager.salvar("Treino adicionado: " + treino.nome);
        System.out.println("Treino adicionado com sucesso!");
    }
    
    static void removerTreino() {
        System.out.println("\n===== REMOVER TREINO =====");
        System.out.println("Digite o número do treino que deseja remover:");
        int indice = scanner.nextInt();
        
        if (indice >= 0 && indice < treinos.size()) {
            Treino treinoRemovido = treinos.remove(indice);
            FileManager.salvar("Treino removido: " + treinoRemovido.nome);
            System.out.println("Treino removido com sucesso!");
        } else {
            System.out.println("Número de treino inválido.");
        }
    }
    
    static void pesquisarTreino() {
        System.out.println("\n===== PESQUISAR TREINO =====");
        System.out.println("Digite o nome do treino que deseja pesquisar:");
        String nome = scanner.nextLine();
        
        boolean encontrado = false;
        for (Treino treino : treinos) {
            if (treino.nome.contains(nome)) {
                System.out.println("Treino encontrado: " + treino.nome);
                encontrado = true;
            }
        }
        
        if (!encontrado) {
            System.out.println("Nenhum treino encontrado com esse nome.");
        }
    }
    
    static void listarTreinos() {
        System.out.println("\n===== LISTAR TODOS OS TREINOS =====");
        if (treinos.isEmpty()) {
            System.out.println("Nenhum treino cadastrado ainda.");
        } else {
            for (int i = 0; i < treinos.size(); i++) {
                System.out.println("[" + i + "] " + treinos.get(i).nome);
            }
        }
    }
    
    static void listarTreinosOrdenados() {
        System.out.println("\n===== LISTAR TREINOS ORDENADOS =====");
        List<String> nomesTreinos = new ArrayList<>();
        for (Treino treino : treinos) {
            nomesTreinos.add(treino.nome);
        }
        Collections.sort(nomesTreinos);
        
        if (nomesTreinos.isEmpty()) {
            System.out.println("Nenhum treino cadastrado ainda.");
        } else {
            for (String nomeTreino : nomesTreinos) {
                System.out.println(nomeTreino);
            }
        }
    }
}